﻿using System;

namespace Tester.Core
{
    public static class Operacoes
    {
        public static double Somar(double primeiroNumero, double segundoNumero)
        {
            return (primeiroNumero + segundoNumero);
        }

        public static double Multiplicar(double primeiroNumero, double segundoNumero)
        {
            return (primeiroNumero * segundoNumero); 
        }
    }
}
